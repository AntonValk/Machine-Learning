In the dataset files the first column is the input variable and the second column is the target variable.
4.2 weights are given in txt file with double line breaks fro each set.